/*

* Copyright (c) MIST JS API 2024 - 2025
* Written by ghgltggamer
* Written date of starting - 23-04-2024

* License
* MIT License

* Copyright (c) 2024 ghgltggamer
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.

*/


// Window class will create a new window and provide the function related to the window

class MIST_Window {
    constructor(title, width, height) {
      this.title = title;
      this.width = width;
      this.height = height;
      this.windowElement = null;
      this.titleBar = null;
      this.terminateButton = null;
      this.maximizeButton = null;
      this.minimizeButton = null;
      this.body = null;
      this.draggable = false;
      this.resizable = false;
  
      this.createWindow();
      this.addTitleBar();
      this.addTerminateButton();
      this.addMaximizeButton();
      this.addMinimizeButton();
      this.addBody();
      this.addEventListeners();
    }
  
    createWindow() {
      this.windowElement = document.createElement('div');
      this.windowElement.classList.add('mist-window');
      this.windowElement.style.width = this.width + 'px';
      this.windowElement.style.height = this.height + 'px';
      this.windowElement.style.position = 'absolute';
      this.windowElement.style.backgroundColor = '#f0f0f0';
      this.windowElement.style.border = '1px solid #ccc';
      document.body.appendChild(this.windowElement);
    }
  
    addTitleBar() {
      this.titleBar = document.createElement('div');
      this.titleBar.classList.add('mist-title-bar');
      this.titleBar.style.width = '100%';
      this.titleBar.style.height = '30px';
      this.titleBar.style.backgroundColor = '#ddd';
      this.titleBar.style.cursor = 'move';
      this.titleBar.innerHTML = this.title;
      this.windowElement.appendChild(this.titleBar);
    }
  
    addTerminateButton() {
      this.terminateButton = document.createElement('button');
      this.terminateButton.classList.add('mist-terminate-button');
      this.terminateButton.style.position = 'absolute';
      this.terminateButton.style.top = '5px';
      this.terminateButton.style.right = '5px';
      this.terminateButton.style.width = '20px';
      this.terminateButton.style.height = '20px';
      this.terminateButton.style.backgroundColor = 'red';
      this.terminateButton.style.border = 'none';
      this.terminateButton.style.color = 'white';
      this.terminateButton.style.fontWeight = 'bold';
      this.terminateButton.innerHTML = 'X';
      this.windowElement.appendChild(this.terminateButton);
    }
  
    addMaximizeButton() {
      this.maximizeButton = document.createElement('button');
      this.maximizeButton.classList.add('mist-maximize-button');
      this.maximizeButton.style.position = 'absolute';
      this.maximizeButton.style.top = '5px';
      this.maximizeButton.style.right = '55px';
      this.maximizeButton.style.width = '20px';
      this.maximizeButton.style.height = '20px';
      this.maximizeButton.style.backgroundColor = '#007bff';
      this.maximizeButton.style.border = 'none';
      this.maximizeButton.style.color = 'white';
      this.maximizeButton.style.fontWeight = 'bold';
      this.maximizeButton.innerHTML = '+';
      this.windowElement.appendChild(this.maximizeButton);
    }
  
    addMinimizeButton() {
      this.minimizeButton = document.createElement('button');
      this.minimizeButton.classList.add('mist-minimize-button');
      this.minimizeButton.style.position = 'absolute';
      this.minimizeButton.style.top = '5px';
      this.minimizeButton.style.right = '30px';
      this.minimizeButton.style.width = '20px';
      this.minimizeButton.style.height = '20px';
      this.minimizeButton.style.backgroundColor = '#28a745';
      this.minimizeButton.style.border = 'none';
      this.minimizeButton.style.color = 'white';
      this.minimizeButton.style.fontWeight = 'bold';
      this.minimizeButton.innerHTML = '-';
      this.windowElement.appendChild(this.minimizeButton);
    }
  
    addBody() {
      this.body = document.createElement('div');
      this.body.classList.add('mist-body');
      this.body.style.width = '100%';
      this.body.style.height = 'calc(100% - 30px)';
      this.body.style.overflow = 'auto';
      this.windowElement.appendChild(this.body);
    }
  
    setContent(htmlContent) {
      this.body.innerHTML = htmlContent;
    }
  
    addEventListeners() {
      // Make the window draggable
      this.titleBar.addEventListener('mousedown', (event) => {
        this.draggable = true;
        this.offsetX = event.clientX - this.windowElement.getBoundingClientRect().left;
        this.offsetY = event.clientY - this.windowElement.getBoundingClientRect().top;
      });
  
      document.addEventListener('mouseup', () => {
        this.draggable = false;
      });
  
      document.addEventListener('mousemove', (event) => {
        if (this.draggable) {
          this.windowElement.style.left = (event.clientX - this.offsetX) + 'px';
          this.windowElement.style.top = (event.clientY - this.offsetY) + 'px';
        }
      });
  
      // Terminate button functionality
      this.terminateButton.addEventListener('click', () => {
        this.windowElement.remove();
      });
    }
  
    fixPosition() {
      this.windowElement.style.position = 'fixed';
    }
  
    fixSize() {
      this.windowElement.style.width = this.width + 'px';
      this.windowElement.style.height = this.height + 'px';
    }
  
    freePosition() {
      this.windowElement.style.position = 'absolute';
    }
  
    freeSize() {
      this.windowElement.style.width = 'auto';
      this.windowElement.style.height = 'auto';
    }
  }
  
  class MIST_Mirror_Window extends MIST_Window {
    constructor(title, width, height, contentUrl) {
      super(title, width, height);
      this.contentUrl = contentUrl;
      this.removeResizeButtons();
      this.addIframe();
    }
  
    addIframe() {
      this.iframe = document.createElement('iframe');
      this.iframe.style.width = '100%';
      this.iframe.style.height = 'calc(100% - 30px)';
      this.iframe.style.border = 'none';
      this.iframe.src = this.contentUrl;
      this.body.appendChild(this.iframe);
    }
  
    removeResizeButtons() {
      if (this.maximizeButton) {
        this.maximizeButton.remove();
      }
      if (this.minimizeButton) {
        this.minimizeButton.remove();
      }
    }
  
    fixPosition() {
      super.fixPosition();
      this.windowElement.style.zIndex = '9999'; // Bring the fixed window to the front
    }
  
    fixSize() {
      super.fixSize();
      this.iframe.style.height = 'calc(100% - 30px)';
    }
  }


  // This was scraped due to fix and free methods 