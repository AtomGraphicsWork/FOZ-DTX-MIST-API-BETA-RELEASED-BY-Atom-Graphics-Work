// MIST MENU BAR will create tabs widgets for your web application
class MIST_MenuBar {
    constructor(containerId) {
      this.container = document.getElementById(containerId);
      if (!this.container) {
        console.error(`Container element with ID '${containerId}' not found.`);
        return;
      }
      this.menus = [];
      this.init();
    }
  
    init() {
      // Add click event listeners to menu titles
      const menuTitles = this.container.querySelectorAll('.menu-title');
      menuTitles.forEach((title) => {
        title.addEventListener('click', () => {
          this.toggleMenuItems(title);
        });
      });
    }
  
    addMenu(menuTitle, menuItems) {
      const menu = {
        title: menuTitle,
        items: menuItems
      };
  
      this.menus.push(menu);
      this.renderMenu(menu);
    }
  
    renderMenu(menu) {
      if (!this.container) {
        console.error('Container element not found.');
        return;
      }
  
      const menuElement = document.createElement('div');
      menuElement.classList.add('menu');
  
      const titleElement = document.createElement('div');
      titleElement.classList.add('menu-title');
      titleElement.textContent = menu.title;
      menuElement.appendChild(titleElement);
  
      const itemsElement = document.createElement('div');
      itemsElement.classList.add('menu-items');
      menu.items.forEach((item) => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('menu-item');
        itemElement.textContent = item.title;
        itemElement.addEventListener('click', item.onClick);
        itemsElement.appendChild(itemElement);
      });
      menuElement.appendChild(itemsElement);
  
      this.container.appendChild(menuElement);
    }
  
    toggleMenuItems(menuTitle) {
      const itemsElement = menuTitle.nextElementSibling;
      itemsElement.style.display = itemsElement.style.display === 'block' ? 'none' : 'block';
    }
  
    clearMenus() {
      if (!this.container) {
        console.error('Container element not found.');
        return;
      }
      this.container.innerHTML = '';
      this.menus = [];
    }
  }
  
  // Usage
  const myMenuBar = new MIST_MenuBar('menu-bar-container');
  if (myMenuBar.container) {
    myMenuBar.addMenu('File', [
      { title: 'New', onClick: () => { console.log('New clicked'); } },
      { title: 'Open', onClick: () => { console.log('Open clicked'); } },
      { title: 'Save', onClick: () => { console.log('Save clicked'); } }
    ]);
  
    myMenuBar.addMenu('Edit', [
      { title: 'Cut', onClick: () => { console.log('Cut clicked'); } },
      { title: 'Copy', onClick: () => { console.log('Copy clicked'); } },
      { title: 'Paste', onClick: () => { console.log('Paste clicked'); } }
    ]);
  }
  