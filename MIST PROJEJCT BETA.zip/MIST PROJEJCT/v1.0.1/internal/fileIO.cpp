#include "lib/cpp/obusaka_fs.hpp"

using namespace std;

FS a;

void open(string file){
    a.open_file = file;
}


void write(string text){
    a.write(text);
}

int read_File(){
    return a.read_file();
}


int read_Line(){
    return a.read_line();
}


void copy(string file){
    a.copy(file);
}


void cut(string file){
    a.move(file);
}


void del(){
    a.del();
}



void clean(){
    a.clean();
}


void restore(){
    a.reset();
}