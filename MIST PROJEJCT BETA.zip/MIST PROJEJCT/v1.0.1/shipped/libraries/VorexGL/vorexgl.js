var VGL = {
  Keys: {
    // Alphabetic keys
    KEY_A: 65,
    KEY_B: 66,
    KEY_C: 67,
    KEY_D: 68,
    KEY_E: 69,
    KEY_F: 70,
    KEY_G: 71,
    KEY_H: 72,
    KEY_I: 73,
    KEY_J: 74,
    KEY_K: 75,
    KEY_L: 76,
    KEY_M: 77,
    KEY_N: 78,
    KEY_O: 79,
    KEY_P: 80,
    KEY_Q: 81,
    KEY_R: 82,
    KEY_S: 83,
    KEY_T: 84,
    KEY_U: 85,
    KEY_V: 86,
    KEY_W: 87,
    KEY_X: 88,
    KEY_Y: 89,
    KEY_Z: 90,

    // Numeric keys
    KEY_0: 48,
    KEY_1: 49,
    KEY_2: 50,
    KEY_3: 51,
    KEY_4: 52,
    KEY_5: 53,
    KEY_6: 54,
    KEY_7: 55,
    KEY_8: 56,
    KEY_9: 57
  },

  
  Input: {
    pressedKeys: new Set(),

    init: function() {
      document.addEventListener('keydown', function(event) {
        VGL.Input.pressedKeys.add(event.keyCode);
      });

      document.addEventListener('keyup', function(event) {
        VGL.Input.pressedKeys.delete(event.keyCode);
      });
    },

    isKeyPressed: function(key) {
      return VGL.Input.pressedKeys.has(key);
    }
  },// input
  
  
  
 // Object for creating movable windows with custom styling
  Window: {
    // Method to create a new window
    // Parameters:
    //   - title: Title of the window
    //   - content: Content of the window
    //   - x: Initial horizontal position of the window
    //   - y: Initial vertical position of the window
    //   - width: Width of the window
    //   - height: Height of the window
    //   - styles: Custom styles for the window (optional)
    //   - titleBarBgColor: Background color of the title bar (optional)
    //   - titleBarTextColor: Text color of the title bar (optional)
    //   - titleBarFont: Font of the title bar (optional)
    create: function(title, content, x, y, width, height, styles, titleBarBgColor, titleBarTextColor, titleBarFont) {
      // Create window element
      var windowElement = document.createElement('div');
      windowElement.className = 'vgl-window';
      windowElement.style.position = 'absolute';
      windowElement.style.left = x + 'px';
      windowElement.style.top = y + 'px';
      windowElement.style.width = width + 'px';
      windowElement.style.height = height + 'px';
      windowElement.innerHTML = '<div class="vgl-window-title">' + title + '<span class="vgl-window-close-btn">×</span></div>' +
                                 '<div class="vgl-window-content">' + content + '</div>';

      // Apply custom styles
      if (styles) {
        Object.assign(windowElement.style, styles);
      }

      // Apply custom title bar styles
      var titleBar = windowElement.querySelector('.vgl-window-title');
      if (titleBarBgColor) {
        titleBar.style.backgroundColor = titleBarBgColor;
      }
      if (titleBarTextColor) {
        titleBar.style.color = titleBarTextColor;
      }
      if (titleBarFont) {
        titleBar.style.fontFamily = titleBarFont;
      }

      // Make the window content non-selectable
      windowElement.querySelector('.vgl-window-content').style.userSelect = 'none';

      // Make the window movable
      var isDragging = false;
      var offsetX, offsetY;

      titleBar.addEventListener('mousedown', function(event) {
        isDragging = true;
        offsetX = event.clientX - windowElement.getBoundingClientRect().left;
        offsetY = event.clientY - windowElement.getBoundingClientRect().top;
      });

      document.addEventListener('mousemove', function(event) {
        if (isDragging) {
          windowElement.style.left = (event.clientX - offsetX) + 'px';
          windowElement.style.top = (event.clientY - offsetY) + 'px';
        }
      });

      document.addEventListener('mouseup', function() {
        isDragging = false;
      });

      // Make the window resizable
      var isResizing = false;
      var originalWidth, originalHeight;

      windowElement.addEventListener('mousedown', function(event) {
        if (event.target === windowElement) {
          isResizing = true;
          originalWidth = windowElement.offsetWidth;
          originalHeight = windowElement.offsetHeight;
          offsetX = event.clientX - windowElement.getBoundingClientRect().right;
          offsetY = event.clientY - windowElement.getBoundingClientRect().bottom;
        }
      });

      document.addEventListener('mousemove', function(event) {
        if (isResizing) {
          var newWidth = originalWidth + event.clientX - windowElement.getBoundingClientRect().right - offsetX;
          var newHeight = originalHeight + event.clientY - windowElement.getBoundingClientRect().bottom - offsetY;
          windowElement.style.width = newWidth + 'px';
          windowElement.style.height = newHeight + 'px';
        }
      });

      document.addEventListener('mouseup', function() {
        isResizing = false;
      });

      // Close button functionality
      var closeButton = windowElement.querySelector('.vgl-window-close-btn');
      closeButton.addEventListener('click', function() {
        document.body.removeChild(windowElement);
      });

      // Close button styles
      closeButton.style.position = 'absolute';
      closeButton.style.top = '0';
      closeButton.style.right = '0';
      closeButton.style.backgroundColor = 'transparent';
      closeButton.style.color = '#ff0000'; // Red color
      closeButton.style.cursor = 'pointer';
      closeButton.style.transition = 'background-color 0.3s';

      // Close button hover styles
      closeButton.addEventListener('mouseenter', function() {
        closeButton.style.backgroundColor = '#ffcccc'; // Light red background on hover
      });

      closeButton.addEventListener('mouseleave', function() {
        closeButton.style.backgroundColor = 'transparent'; // Restore transparent background on mouse leave
      });

      document.body.appendChild(windowElement);
    }
  },// window
  
  
  
  
  
  // 3d rendering concepts
  
  
  
  Context_3d: {
    // Method to create a new 3D context window
    createWindow: function(title, x, y, width, height, styles, titleBarBgColor, titleBarTextColor, titleBarFont) {
      // Create 3D context window element
      var windowElement = document.createElement('div');
      windowElement.className = 'vgl-window vgl-3d-window';
      windowElement.style.position = 'absolute';
      windowElement.style.left = x + 'px';
      windowElement.style.top = y + 'px';
      windowElement.style.width = width + 'px';
      windowElement.style.height = height + 'px';
      windowElement.innerHTML = '<div class="vgl-window-title">' + title + '<span class="vgl-window-close-btn">×</span></div>' +
                                 '<div class="vgl-window-content vgl-3d-content"></div>';

      // Apply custom styles
      if (styles) {
        Object.assign(windowElement.style, styles);
      }

      // Apply custom title bar styles
      var titleBar = windowElement.querySelector('.vgl-window-title');
      if (titleBarBgColor) {
        titleBar.style.backgroundColor = titleBarBgColor;
      }
      if (titleBarTextColor) {
        titleBar.style.color = titleBarTextColor;
      }
      if (titleBarFont) {
        titleBar.style.fontFamily = titleBarFont;
      }

      // Make the window movable
      var isDragging = false;
      var offsetX, offsetY;

      titleBar.addEventListener('mousedown', function(event) {
        isDragging = true;
        offsetX = event.clientX - windowElement.getBoundingClientRect().left;
        offsetY = event.clientY - windowElement.getBoundingClientRect().top;
      });

      document.addEventListener('mousemove', function(event) {
        if (isDragging) {
          windowElement.style.left = (event.clientX - offsetX) + 'px';
          windowElement.style.top = (event.clientY - offsetY) + 'px';
        }
      });

      document.addEventListener('mouseup', function() {
        isDragging = false;
      });

      // Make the window resizable
      var isResizing = false;
      var originalWidth, originalHeight;

      windowElement.addEventListener('mousedown', function(event) {
        if (event.target === windowElement) {
          isResizing = true;
          originalWidth = windowElement.offsetWidth;
          originalHeight = windowElement.offsetHeight;
          offsetX = event.clientX - windowElement.getBoundingClientRect().right;
          offsetY = event.clientY - windowElement.getBoundingClientRect().bottom;
        }
      });

      document.addEventListener('mousemove', function(event) {
        if (isResizing) {
          var newWidth = originalWidth + event.clientX - windowElement.getBoundingClientRect().right - offsetX;
          var newHeight = originalHeight + event.clientY - windowElement.getBoundingClientRect().bottom - offsetY;
          windowElement.style.width = newWidth + 'px';
          windowElement.style.height = newHeight + 'px';
        }
      });

      document.addEventListener('mouseup', function() {
        isResizing = false;
      });

      // Close button functionality
      var closeButton = windowElement.querySelector('.vgl-window-close-btn');
      closeButton.addEventListener('click', function() {
        document.body.removeChild(windowElement);
      });

      // Close button styles
      closeButton.style.position = 'absolute';
      closeButton.style.top = '0';
      closeButton.style.right = '0';
      closeButton.style.backgroundColor = 'transparent';
      closeButton.style.color = '#ff0000'; // Red color
      closeButton.style.cursor = 'pointer';
      closeButton.style.transition = 'background-color 0.3s';

      // Close button hover styles
      closeButton.addEventListener('mouseenter', function() {
        closeButton.style.backgroundColor = '#ffcccc'; // Light red background on hover
      });

      closeButton.addEventListener('mouseleave', function() {
        closeButton.style.backgroundColor = 'transparent'; // Restore transparent background on mouse leave
      });

      document.body.appendChild(windowElement);

      return windowElement.querySelector('.vgl-3d-content');
    },

    // Method to create a 3D cube with textures
    createCube: function(container, size, position, colors, textures, rotation) {
      // Create cube element
      var cube = document.createElement('div');
      cube.className = 'vgl-3d-cube';
      cube.style.position = 'absolute';
      cube.style.width = size + 'px';
      cube.style.height = size + 'px';
      cube.style.transformStyle = 'preserve-3d';
      cube.style.transform = 'translate3d(' + position.x + 'px, ' + position.y + 'px, ' + position.z + 'px) ' +
        'rotateX(' + rotation.x + 'deg) rotateY(' + rotation.y + 'deg) rotateZ(' + rotation.z + 'deg)';
    
      // Define colors for each face of the cube
      var faceColors = colors || ['white', 'white', 'white', 'white', 'white', 'white'];
    
      // Create faces for the cube
      var faces = [
        { name: 'front', transform: 'translateZ(' + (size / 2) + 'px)', bgColor: faceColors[0], texture: textures ? textures[0] : null },
        { name: 'back', transform: 'translateZ(' + (-size / 2) + 'px) rotateY(180deg)', bgColor: faceColors[1], texture: textures ? textures[1] : null },
        { name: 'left', transform: 'translateX(' + (-size / 2) + 'px) rotateY(-90deg)', bgColor: faceColors[2], texture: textures ? textures[2] : null },
        { name: 'right', transform: 'translateX(' + (size / 2) + 'px) rotateY(90deg)', bgColor: faceColors[3], texture: textures ? textures[3] : null },
        { name: 'top', transform: 'translateY(' + (-size / 2) + 'px) rotateX(90deg)', bgColor: faceColors[4], texture: textures ? textures[4] : null },
        { name: 'bottom', transform: 'translateY(' + (size / 2) + 'px) rotateX(-90deg)', bgColor: faceColors[5], texture: textures ? textures[5] : null }
      ];
    
      faces.forEach(function(face, index) {
        var faceElement = document.createElement('div');
        faceElement.className = 'vgl-3d-cube-face vgl-3d-cube-face-' + face.name;
        faceElement.style.position = 'absolute';
        faceElement.style.width = size + 'px';
        faceElement.style.height = size + 'px';
        if (face.texture) {
          faceElement.style.backgroundImage = 'url(' + face.texture + ')';
          faceElement.style.backgroundSize = 'cover';
        } else {
          faceElement.style.backgroundColor = face.bgColor;
        }
        faceElement.style.transform = face.transform;
        cube.appendChild(faceElement);
      });
    
      container.appendChild(cube);
    }, // create cube 
    
    
    

    // Method to get mouse position
    Mouse: {
      x: 0,
      y: 0,
      init: function() {
        document.addEventListener('mousemove', function(event) {
          VGL.Context_3d.Mouse.x = event.clientX;
          VGL.Context_3d.Mouse.y = event.clientY;
        });
      }
    }, //mpuse pos
    
    
    
    // Method to create a 3D light
    createLight: function(type, color, intensity, position, shadows) {
      var light = document.createElement('div');
      light.className = 'vgl-3d-light vgl-3d-' + type + '-light';
      light.style.position = 'absolute';
      light.style.backgroundColor = color || '#ffffff';
      light.style.opacity = intensity || 1;
      light.style.left = position.x + 'px';
      light.style.top = position.y + 'px';
      light.style.transform = 'translateZ(' + position.z + 'px)';
    
      if (shadows) {
        light.style.boxShadow = '10px 10px 20px rgba(0, 0, 0, 0.5)';
      }
    
      document.body.appendChild(light);
    }//light 
    
  } ,// 3d render
  
  
  
  
  
  
  
  // gui
  
  get_node: function(elementId) {
    var element = document.getElementById(elementId);
  
    if (!element) {
      console.error('Element with ID ' + elementId + ' not found.');
      return null;
    }
  
    // Private variables for connected nodes and shared data
    var connectedNodes = [];
    var sharedData = {};
  
    // Public methods and properties
    var node = {
      // Getters
      get id() {
        return element.id;
      },
      get tagName() {
        return element.tagName;
      },
      get classList() {
        return element.classList;
      },
      get style() {
        return element.style;
      },
      getBoundingClientRect: function() {
        return element.getBoundingClientRect();
      },
  
      // Setters
      set id(newId) {
        element.id = newId;
      },
      setAttribute: function(name, value) {
        element.setAttribute(name, value);
      },
      removeAttribute: function(name) {
        element.removeAttribute(name);
      },
      addClass: function(className) {
        element.classList.add(className);
      },
      removeClass: function(className) {
        element.classList.remove(className);
      },
  
      // Manipulation
      appendChild: function(child) {
        element.appendChild(child);
      },
      removeChild: function(child) {
        element.removeChild(child);
      },
      remove: function() {
        element.parentNode.removeChild(element);
      },
  
      // Connect nodes
      connectNode: function(otherNode) {
        if (!connectedNodes.includes(otherNode)) {
          connectedNodes.push(otherNode);
          otherNode.connectNode(node); // Bidirectional connection
        }
      },
  
      // Share data with connected nodes
      setData: function(key, value) {
        sharedData[key] = value;
        connectedNodes.forEach(function(connectedNode) {
          connectedNode.setData(key, value); // Share data with connected nodes
        });
      },
      getData: function(key) {
        return sharedData[key];
      }
    };
  
    return node;
  }
 };
  






















// Example usage:
// Example usage:
// var container = VGL.Context_3d.createWindow('3D Scene', 100, 100, 400, 300);
// VGL.Context_3d.createCube(container, 50, { x: 0, y: 0, z: 0 }, 'red', { x: 45, y: 45, z: 0 });
// VGL.Context_3d.createCube(container, 50, { x: 100, y: 0, z: 0 }, 'green', { x: 45, y: -45, z: 0 });
// VGL.Context_3d.createCube(container, 50, { x: -100, y: 0, z: 0 }, 'blue', { x: 45, y: 0, z: 45 });


// const game = VGL.Context_3d.createWindow('VGL 1.0 - 3d Render', 0, 0, 200, 100)

// VGL.Context_3d.createCube(game, 30, {x:0, y:0, z:0}, 'red', {x:23, y:34, z:0})


// // Example usage:
// var container = VGL.Context_3d.createWindow('3D Scene', 100, 100, 400, 300);

// // Define colors for each face of the cube
// var colors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple'];

// // Create a 3D cube with custom colors for each face
// VGL.Context_3d.createCube(container, 100, { x: 0, y: 0, z: 0 }, colors, { x: -25, y: 45, z: 0 });


// Example usage:
var customStyles = {
  backgroundColor: '#f0f0f0',
  border: '1px solid #ccc',
  borderRadius: '5px',
  boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.1)'
};

/*VGL.Window.create(
  'My Window', 
  'Window content goes here', 
  100, 
  100, 
  200, 
  150, 
  customStyles, 
  '#ddd', // Title bar background color
  '#333', // Title bar text color
  'Arial' // Title bar font
);*/






// Example usage:
//



// // Initialize mouse tracking
// VGL.Context_3d.Mouse.init();

// // Create a 3D window
// var container = VGL.Context_3d.createWindow('3D Scene', 100, 100, 400, 300, {
//   perspective: '1000px' // Apply perspective to the 3D scene
// });

// // Define colors for each face of the cube
// var colors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple'];

// // Create a 3D cube with colors for each face
// var cubePosition = { x: 200, y: 150, z: 0 };
// var cubeSize = 100;
// var cubeRotation = { x: 45, y: 45, z: 0 };
// VGL.Context_3d.createCube(container, cubeSize, cubePosition, colors, null, cubeRotation);

// // Create a directional light
// var lightPosition = { x: 100, y: 100, z: 200 };
// VGL.Context_3d.createLight('directional', 'white', 0.8, lightPosition, true);




// // Initialize mouse tracking
// VGL.Context_3d.Mouse.init();

// // Create a 3D window
// var container = VGL.Context_3d.createWindow('3D Scene', 100, 100, 400, 300, {
//   perspective: '1000px', // Apply perspective to the 3D scene
//   overflow: 'hidden' // Ensure that shadows are visible within the window bounds
// });

// // Define colors for each face of the cube
// var colors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple'];

// // Create a 3D cube with colors for each face
// var cubePosition = { x: 200, y: 150, z: 0 };
// var cubeSize = 100;
// var cubeRotation = { x: 0, y: 0, z: 0 };
// VGL.Context_3d.createCube(container, cubeSize, cubePosition, colors, null, cubeRotation);

// // Create a directional light
// var lightPosition = { x: 100, y: 100, z: 400 }; // Adjusted z-position for better shadow rendering
// VGL.Context_3d.createLight('directional', 'white', 0.8, lightPosition, true);










// gui

var VGL_GUI = {
  // Method to create a window
  createWindow: function(title, x, y, width, height) {
    var windowContainer = document.createElement('div');
    windowContainer.className = 'vgl-gui-window';
    windowContainer.style.position = 'absolute';
    windowContainer.style.left = x + 'px';
    windowContainer.style.top = y + 'px';
    windowContainer.style.width = width + 'px';
    windowContainer.style.height = height + 'px';
    windowContainer.style.border = '1px solid #ccc';
    windowContainer.style.overflow = 'auto';

    var titleBar = document.createElement('div');
    titleBar.className = 'vgl-gui-window-title-bar';
    titleBar.innerText = title;
    titleBar.style.backgroundColor = '#f0f0f0';
    titleBar.style.borderBottom = '1px solid #ccc';
    titleBar.style.padding = '4px';
    titleBar.style.cursor = 'move';
    titleBar.style.userSelect = 'none';
    windowContainer.appendChild(titleBar);

    var isDragging = false;
    var offset = { x: 0, y: 0 };

    titleBar.addEventListener('mousedown', function(event) {
      isDragging = true;
      offset.x = event.clientX - windowContainer.offsetLeft;
      offset.y = event.clientY - windowContainer.offsetTop;
    });

    document.addEventListener('mousemove', function(event) {
      if (isDragging) {
        windowContainer.style.left = (event.clientX - offset.x) + 'px';
        windowContainer.style.top = (event.clientY - offset.y) + 'px';
      }
    });

    document.addEventListener('mouseup', function() {
      isDragging = false;
    });

    document.body.appendChild(windowContainer);

    return windowContainer;
  },

  // Method to create a button
  createButton: function(window, text, x, y, width, height, callback) {
    var button = document.createElement('button');
    button.innerText = text;
    button.style.position = 'absolute';
    button.style.left = x + 'px';
    button.style.top = y + 'px';
    button.style.width = width + 'px';
    button.style.height = height + 'px';
    button.onclick = callback;
    window.appendChild(button);
  },

  // Method to create an input field
  createInputField: function(window, x, y, width, height, placeholder) {
    var inputField = document.createElement('input');
    inputField.type = 'text';
    inputField.placeholder = placeholder || '';
    inputField.style.position = 'absolute';
    inputField.style.left = x + 'px';
    inputField.style.top = y + 'px';
    inputField.style.width = width + 'px';
    inputField.style.height = height + 'px';
    window.appendChild(inputField);
  }
};






// Create a window
// Create a VGL window
// Create a VGL window
//var vglWindow = VGL.Window.create('VGL Window', 100, 100, 300, 200);

// Create a button inside the VGL window
//VGL_GUI.createButton(vglWindow, 'Click Me', 50, 50, 100, 30, function() {
//  alert('Button clicked!');
//});

// Create an input field inside the VGL window
//VGL_GUI.createInputField(vglWindow, 50, 100, 200, 30, 'Enter your name');










// VGL_UI
var VGL_UI = {
  // Method to create a menu bar
  createMenuBar: function(label, items) {
    var menuBar = document.createElement('ul');
    menuBar.className = 'vgl-ui-menu-bar';
    menuBar.style.position = 'fixed';
    menuBar.style.top = '0';
    menuBar.style.left = '0';
    menuBar.style.padding = '10px';
    menuBar.style.margin = '0';
    menuBar.style.listStyle = 'none';
    menuBar.style.backgroundColor = '#f2f2f2';
    menuBar.style.borderBottom = '1px solid #ccc';
    menuBar.style.zIndex = '1000';

    var menuLabel = document.createElement('li');
    menuLabel.textContent = label;
    menuLabel.style.display = 'inline-block';
    menuLabel.style.padding = '5px 10px';
    menuLabel.style.cursor = 'pointer';
    menuBar.appendChild(menuLabel);

    items.forEach(function(item) {
      var menuItem = document.createElement('li');
      menuItem.textContent = item.label;
      menuItem.className = 'menu-item';
      menuItem.style.display = 'none';
      menuItem.style.padding = '5px 10px';
      menuItem.style.cursor = 'pointer';
      menuItem.style.backgroundColor = '#fff';
      menuItem.style.borderBottom = '1px solid #ccc';

      menuItem.addEventListener('mouseenter', function() {
        menuItem.style.backgroundColor = '#e6e6e6';
      });

      menuItem.addEventListener('mouseleave', function() {
        menuItem.style.backgroundColor = '#fff';
      });

      menuItem.onclick = item.onclick;
      menuBar.appendChild(menuItem);

      menuLabel.addEventListener('mouseenter', function() {
        menuItem.style.display = 'block';
      });

      menuLabel.addEventListener('mouseleave', function() {
        menuItem.style.display = 'none';
      });
    });

    document.body.appendChild(menuBar);

    return menuBar;
  },

  // Method to create a dropdown menu
  createDropdownMenu: function(options, x, y) {
    var dropdownMenu = document.createElement('select');
    dropdownMenu.className = 'vgl-ui-dropdown-menu';
    dropdownMenu.style.position = 'absolute';
    dropdownMenu.style.left = x + 'px';
    dropdownMenu.style.top = y + 'px';
    dropdownMenu.style.padding = '5px';
    dropdownMenu.style.border = '1px solid #ccc';
    dropdownMenu.style.borderRadius = '3px';

    options.forEach(function(option) {
      var optionElement = document.createElement('option');
      optionElement.textContent = option.label;
      optionElement.value = option.value;
      dropdownMenu.appendChild(optionElement);
    });

    document.body.appendChild(dropdownMenu);

    return dropdownMenu;
  },

  // Method to create a checkbox
  createCheckbox: function(label, x, y) {
    var checkboxContainer = document.createElement('label');
    checkboxContainer.className = 'vgl-ui-checkbox';
    checkboxContainer.style.position = 'absolute';
    checkboxContainer.style.left = x + 'px';
    checkboxContainer.style.top = y + 'px';
    checkboxContainer.style.display = 'inline-block';
    checkboxContainer.style.paddingLeft = '25px';
    checkboxContainer.style.cursor = 'pointer';
    checkboxContainer.style.color = '#333';

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.style.position = 'absolute';
    checkbox.style.left = '0';
    checkbox.style.top = '0';
    checkboxContainer.appendChild(checkbox);

    var checkmark = document.createElement('span');
    checkmark.className = 'checkmark';
    checkmark.style.position = 'absolute';
    checkmark.style.left = '0';
    checkmark.style.top = '0';
    checkmark.style.width = '16px';
    checkmark.style.height = '16px';
    checkmark.style.border = '1px solid #ccc';
    checkmark.style.borderRadius = '3px';

    checkboxContainer.appendChild(checkmark);

    var labelText = document.createElement('span');
    labelText.textContent = label;
    labelText.style.position = 'relative';
    labelText.style.top = '-2px';
    checkboxContainer.appendChild(labelText);

    document.body.appendChild(checkboxContainer);

    return checkbox;
  },

  // Method to create a radio button
  createRadioButton: function(label, groupName, x, y) {
    var radioButtonContainer = document.createElement('label');
    radioButtonContainer.className = 'vgl-ui-radio-button';
    radioButtonContainer.style.position = 'absolute';
    radioButtonContainer.style.left = x + 'px';
    radioButtonContainer.style.top = y + 'px';
    radioButtonContainer.style.display = 'inline-block';
    radioButtonContainer.style.paddingLeft = '25px';
    radioButtonContainer.style.cursor = 'pointer';
    radioButtonContainer.style.color = '#333';

    var radioButton = document.createElement('input');
    radioButton.type = 'radio';
    radioButton.name = groupName;
    radioButton.style.position = 'absolute';
    radioButton.style.left = '0';
    radioButton.style.top = '0';
    radioButtonContainer.appendChild(radioButton);

    var checkmark = document.createElement('span');
    checkmark.className = 'checkmark';
    checkmark.style.position = 'absolute';
    checkmark.style.left = '0';
    checkmark.style.top = '0';
    checkmark.style.width = '16px';
    checkmark.style.height = '16px';
    checkmark.style.border = '1px solid #ccc';
    checkmark.style.borderRadius = '50%';
    radioButtonContainer.appendChild(checkmark);

    var labelText = document.createElement('span');
    labelText.textContent = label;
    labelText.style.position = 'relative';
    labelText.style.top = '-2px';
    radioButtonContainer.appendChild(labelText);

    document.body.appendChild(radioButtonContainer);

    return radioButton;
  },

  // Method to create a toggle switch
  createToggleSwitch: function(checked, x, y) {
    var toggleSwitchContainer = document.createElement('label');
    toggleSwitchContainer.className = 'vgl-ui-toggle-switch';
    toggleSwitchContainer.style.position = 'absolute';
    toggleSwitchContainer.style.left = x + 'px';
    toggleSwitchContainer.style.top = y + 'px';
    toggleSwitchContainer.style.display = 'inline-block';
    toggleSwitchContainer.style.paddingLeft = '25px';
    toggleSwitchContainer.style.cursor = 'pointer';
    toggleSwitchContainer.style.color = '#333';

    var toggleSwitch = document.createElement('input');
    toggleSwitch.type = 'checkbox';
    toggleSwitch.checked = checked;
    toggleSwitch.style.position = 'absolute';
    toggleSwitch.style.left = '0';
    toggleSwitch.style.top = '0';
    toggleSwitchContainer.appendChild(toggleSwitch);

    var slider = document.createElement('span');
    slider.className = 'slider';
    slider.style.position = 'absolute';
    slider.style.left = '0';
    slider.style.top = '0';
    slider.style.width = '40px';
    slider.style.height = '20px';
    slider.style.backgroundColor = '#ccc';
    slider.style.borderRadius = '10px';
    slider.style.transition = '0.4s';

    toggleSwitchContainer.appendChild(slider);

    document.body.appendChild(toggleSwitchContainer);

    return toggleSwitch;
  },

  // Method to create a progress bar
  createProgressBar: function(value, x, y, width, height) {
    var progressBar = document.createElement('progress');
    progressBar.className = 'vgl-ui-progress-bar';
    progressBar.style.position = 'absolute';
    progressBar.style.left = x + 'px';
    progressBar.style.top = y + 'px';
    progressBar.style.width = width + 'px';
    progressBar.style.height = height + 'px';
    progressBar.style.backgroundColor = '#f2f2f2';
    progressBar.style.border = '1px solid #ccc';
    progressBar.value = value;

    document.body.appendChild(progressBar);

    return progressBar;
  },

  // Method to create a slider
  createSlider: function(min, max, value, x, y, width) {
    var slider = document.createElement('input');
    slider.type = 'range';
    slider.className = 'vgl-ui-slider';
    slider.style.position = 'absolute';
    slider.style.left = x + 'px';
    slider.style.top = y + 'px';
    slider.style.width = width + 'px';
    slider.min = min;
    slider.max = max;
    slider.value = value;

    document.body.appendChild(slider);

    return slider;
  },

// Method to create tabs
createTabs: function(tabs, x, y) {
  var tabsContainer = document.createElement('div');
  tabsContainer.className = 'vgl-ui-tabs';
  tabsContainer.style.position = 'absolute';
  tabsContainer.style.left = x + 'px';
  tabsContainer.style.top = y + 'px';
  tabsContainer.style.backgroundColor = '#f2f2f2';
  tabsContainer.style.border = '1px solid #ccc';
  tabsContainer.style.borderRadius = '5px';
  tabsContainer.style.overflow = 'hidden';

  tabs.forEach(function(tab) {
    var tabButton = document.createElement('button');
    tabButton.textContent = tab.label;
    tabButton.className = 'tab-button';
    tabButton.style.padding = '10px 15px';
    tabButton.style.border = 'none';
    tabButton.style.backgroundColor = 'transparent';
    tabButton.style.cursor = 'pointer';
    tabButton.style.float = 'left';
    tabButton.style.transition = 'background-color 0.3s';

    tabButton.addEventListener('click', function() {
      var i, tabContent;
      tabContent = document.getElementsByClassName('tab-content');
      for (i = 0; i < tabContent.length; i++) {
        tabContent[i].style.display = 'none';
      }
      var activeTab = document.getElementById(tab.panelId);
      activeTab.style.display = 'block';

      var btns = document.getElementsByClassName('tab-button');
      for (i = 0; i < btns.length; i++) {
        btns[i].style.backgroundColor = '#f2f2f2';
      }
      this.style.backgroundColor = '#ddd';
    });

    tabsContainer.appendChild(tabButton);
  });

  var tabContents = document.createElement('div');
  tabContents.className = 'tab-contents';
  tabsContainer.appendChild(tabContents);

  tabs.forEach(function(tab) {
    var tabContent = document.createElement('div');
    tabContent.id = tab.panelId;
    tabContent.className = 'tab-content';
    tabContent.style.display = 'none';
    tabContent.style.padding = '10px';
    tabContent.textContent = tab.content;
    tabContents.appendChild(tabContent);
  });

  document.body.appendChild(tabsContainer);

  return tabsContainer;
},

// Method to create an accordion
createAccordion: function(items, x, y) {
  var accordionContainer = document.createElement('div');
  accordionContainer.className = 'vgl-ui-accordion';
  accordionContainer.style.position = 'absolute';
  accordionContainer.style.left = x + 'px';
  accordionContainer.style.top = y + 'px';

  items.forEach(function(item) {
    var accordionItem = document.createElement('div');
    accordionItem.className = 'accordion-item';

    var accordionButton = document.createElement('button');
    accordionButton.textContent = item.title;
    accordionButton.className = 'accordion-button';
    accordionButton.onclick = function() {
      var panel = accordionItem.nextElementSibling;
      if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
      } else {
        panel.style.maxHeight = panel.scrollHeight + 'px';
      }
    };
    accordionItem.appendChild(accordionButton);

    var accordionPanel = document.createElement('div');
    accordionPanel.className = 'accordion-panel';
    accordionPanel.textContent = item.content;
    accordionItem.appendChild(accordionPanel);

    accordionContainer.appendChild(accordionItem);
  });

  document.body.appendChild(accordionContainer);

  return accordionContainer;
}
};// ui end

// Example usage:
/*var menuItems = [
  { label: 'File', items: [
    { label: 'New', onclick: function() { console.log('New file clicked'); } },
    { label: 'Open', onclick: function() { console.log('Open file clicked'); } },
    { label: 'Save', onclick: function() { console.log('Save file clicked'); } }
  ] },
  { label: 'Edit', items: [
    { label: 'Cut', onclick: function() { console.log('Cut clicked'); } },
    { label: 'Copy', onclick: function() { console.log('Copy clicked'); } },
    { label: 'Paste', onclick: function() { console.log('Paste clicked'); } }
  ] }
];

var menuBar = VGL_UI.createMenuBar('Menu', menuItems);

var tabs = [
  { label: 'Tab 1', panelId: 'tab1', content: 'Content for Tab 1' },
  { label: 'Tab 2', panelId: 'tab2', content: 'Content for Tab 2' },
  { label: 'Tab 3', panelId: 'tab3', content: 'Content for Tab 3' }
];

var tabsContainer = VGL_UI.createTabs(tabs, 100, 100);

var accordionItems = [
  { title: 'Section 1', content: 'Content for section 1' },
  { title: 'Section 2', content: 'Content for section 2' },
  { title: 'Section 3', content: 'Content for section 3' }
];

var accordion = VGL_UI.createAccordion(accordionItems, 100, 300);*/




// code editor program 
/*var VGL_UI = {
  // Method to create a menu bar
  createMenuBar: function(labels) {
    var menuBar = document.createElement('ul');
    menuBar.className = 'vgl-ui-menu-bar';
    menuBar.style.listStyle = 'none';
    menuBar.style.margin = '0';
    menuBar.style.padding = '0';
    menuBar.style.backgroundColor = '#ddd';
    menuBar.style.borderBottom = '1px solid #ccc';

    labels.forEach(function(label) {
      var menuItem = document.createElement('li');
      menuItem.textContent = label;
      menuItem.style.float = 'left';
      menuItem.style.padding = '10px';
      menuItem.style.cursor = 'pointer';
      menuBar.appendChild(menuItem);
    });

    return menuBar;
  },

  // Method to create a toolbar
  createToolBar: function(buttons) {
    var toolBar = document.createElement('div');
    toolBar.className = 'vgl-ui-tool-bar';
    toolBar.style.backgroundColor = '#f2f2f2';
    toolBar.style.borderBottom = '1px solid #ccc';
    toolBar.style.padding = '5px';

    buttons.forEach(function(button) {
      var btn = document.createElement('button');
      btn.textContent = button.label;
      btn.style.padding = '5px 10px';
      btn.style.marginRight = '10px';
      toolBar.appendChild(btn);
    });

    return toolBar;
  },

  // Method to create a code editor
  createCodeEditor: function(x, y, width, height) {
    var editorContainer = document.createElement('div');
    editorContainer.className = 'vgl-ui-code-editor';
    editorContainer.style.position = 'absolute';
    editorContainer.style.left = x + 'px';
    editorContainer.style.top = y + 'px';
    editorContainer.style.width = width + 'px';
    editorContainer.style.height = height + 'px';
    editorContainer.style.border = '1px solid #ccc';
    editorContainer.style.backgroundColor = '#f9f9f9';
    editorContainer.style.fontFamily = 'monospace';
    editorContainer.style.overflow = 'hidden';

    return editorContainer;
  }
};

// Example usage:
var menuLabels = ['File', 'Edit'];
var menuBar = VGL_UI.createMenuBar(menuLabels);
document.body.appendChild(menuBar);

var buttons = [
  { label: 'Undo' },
  { label: 'Redo' },
  { label: 'Save' }
];
var toolBar = VGL_UI.createToolBar(buttons);
document.body.appendChild(toolBar);

var editorContainer = VGL_UI.createCodeEditor(50, 100, 600, 400);
document.body.appendChild(editorContainer);

var codeEditor = document.createElement('textarea');
codeEditor.className = 'vgl-ui-code-textarea';
codeEditor.style.width = '100%';
codeEditor.style.height = 'calc(100% - 40px)';
codeEditor.style.border = 'none';
codeEditor.style.backgroundColor = 'transparent';
codeEditor.style.padding = '10px';
codeEditor.style.fontFamily = 'inherit';
codeEditor.style.fontSize = '14px';
codeEditor.style.resize = 'none';

editorContainer.appendChild(codeEditor);*/









// NXT UI
var VGL_NXT_UI = {
  createMenuBar: function(menu, options) {
    var menuBar = document.createElement('div');
    menuBar.className = 'vgl-nxt-menu-bar';
    menuBar.style.display = 'flex';
    menuBar.style.alignItems = 'center';
    menuBar.style.backgroundColor = '#fff';
    menuBar.style.borderBottom = '1px solid #ccc';
    menuBar.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.1)';
    menuBar.style.zIndex = '999';

    if (options && options.elementId) {
      var parentElement = document.getElementById(options.elementId);
      if (parentElement) {
        parentElement.appendChild(menuBar);
      } else {
        document.body.appendChild(menuBar);
      }
    } else {
      document.body.appendChild(menuBar);
    }

    menu.forEach(function(item) {
      if (item !== null) {
        var menuItem = document.createElement('div');
        menuItem.textContent = item;
        menuItem.className = 'vgl-nxt-menu-item';
        menuItem.style.padding = '10px';
        menuItem.style.cursor = 'pointer';
        menuItem.style.transition = 'background-color 0.3s';

        menuItem.addEventListener('mouseenter', function() {
          this.style.backgroundColor = '#f2f2f2';
        });

        menuItem.addEventListener('mouseleave', function() {
          this.style.backgroundColor = 'transparent';
        });

        menuBar.appendChild(menuItem);
      }
    });

    return menuBar;
  },

  createDropDownMenu: function(menu, options) {
    var dropDownMenu = document.createElement('div');
    dropDownMenu.className = 'vgl-nxt-drop-down-menu';
    dropDownMenu.style.position = 'absolute';
    dropDownMenu.style.top = '100%';
    dropDownMenu.style.backgroundColor = '#fff';
    dropDownMenu.style.border = '1px solid #ccc';
    dropDownMenu.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.1)';
    dropDownMenu.style.zIndex = '999';

    if (options && options.elementId) {
      var parentElement = document.getElementById(options.elementId);
      if (parentElement) {
        parentElement.appendChild(dropDownMenu);
      } else {
        document.body.appendChild(dropDownMenu);
      }
    } else {
      document.body.appendChild(dropDownMenu);
    }

    menu.forEach(function(item) {
      if (item !== null) {
        var menuItem = document.createElement('div');
        menuItem.textContent = item;
        menuItem.className = 'vgl-nxt-drop-down-item';
        menuItem.style.padding = '10px';
        menuItem.style.cursor = 'pointer';
        menuItem.style.transition = 'background-color 0.3s';

        menuItem.addEventListener('mouseenter', function() {
          this.style.backgroundColor = '#f2f2f2';
        });

        menuItem.addEventListener('mouseleave', function() {
          this.style.backgroundColor = 'transparent';
        });

        dropDownMenu.appendChild(menuItem);
      }
    });

    return dropDownMenu;
  },

  createSlider: function(options) {
    var sliderContainer = document.createElement('div');
    sliderContainer.className = 'vgl-nxt-slider-container';
    sliderContainer.style.width = options.width || '200px';
    sliderContainer.style.margin = '10px';

    var sliderLabel = document.createElement('div');
    sliderLabel.textContent = options.label || 'Slider';
    sliderLabel.style.marginBottom = '5px';
    sliderContainer.appendChild(sliderLabel);

    var slider = document.createElement('input');
    slider.type = 'range';
    slider.min = options.min || '0';
    slider.max = options.max || '100';
    slider.value = options.value || '50';
    slider.className = 'vgl-nxt-slider';
    slider.style.width = '100%';
    slider.style.cursor = 'pointer';
    slider.style.outline = 'none';
    slider.style.border = 'none';

    if (options.onInput) {
      slider.addEventListener('input', options.onInput);
    }

    sliderContainer.appendChild(slider);

    return sliderContainer;
  },

  createTabsBar: function(tabs, options) {
    var tabsBar = document.createElement('div');
    tabsBar.className = 'vgl-nxt-tabs-bar';
    tabsBar.style.display = 'flex';
    tabsBar.style.backgroundColor = '#fff';
    tabsBar.style.borderBottom = '1px solid #ccc';
  
    if (options && options.elementId) {
      var parentElement = document.getElementById(options.elementId);
      if (parentElement) {
        parentElement.appendChild(tabsBar);
      } else {
        document.body.appendChild(tabsBar);
      }
    } else {
      document.body.appendChild(tabsBar);
    }
  
    tabs.forEach(function(tab) {
      var tabItem = document.createElement('div');
      tabItem.textContent = tab.label;
      tabItem.className = 'vgl-nxt-tab-item';
      tabItem.style.padding = '10px';
      tabItem.style.cursor = 'pointer';
      tabItem.style.transition = 'background-color 0.3s';
  
      tabItem.addEventListener('mouseenter', function() {
        this.style.backgroundColor = '#f2f2f2';
      });
  
      tabItem.addEventListener('mouseleave', function() {
        this.style.backgroundColor = 'transparent';
      });
  
      if (tab.id) {
        tabItem.id = tab.id;
      }
  
      tabsBar.appendChild(tabItem);
    });
  
    return tabsBar;
  }
};
































// NTL
var VGL_NTL_GUI = {
  // Button widget
  Button: function(label) {
    var button = document.createElement('button');
    button.textContent = label;
    button.className = 'vgl-ntl-button';

    // Add hover transition
    button.addEventListener('mouseenter', function() {
      button.style.backgroundColor = '#f2f2f2';
    });

    button.addEventListener('mouseleave', function() {
      button.style.backgroundColor = 'transparent';
    });

    // Styling methods
    button.setStyle = function(styles) {
      Object.assign(button.style, styles);
    };

    return button;
  },

  // Input field widget
  InputField: function() {
    var inputField = document.createElement('input');
    inputField.className = 'vgl-ntl-input-field';

    // Add hover transition
    inputField.addEventListener('mouseenter', function() {
      inputField.style.borderColor = '#999';
    });

    inputField.addEventListener('mouseleave', function() {
      inputField.style.borderColor = '#ccc';
    });

    // Styling methods
    inputField.setStyle = function(styles) {
      Object.assign(inputField.style, styles);
    };

    return inputField;
  },

  // Dropdown menu widget
  DropdownMenu: function(options) {
      var dropdownMenu = document.createElement('select');
      dropdownMenu.className = 'vgl-ntl-dropdown-menu';
  
      options.forEach(function(option) {
        var optionElement = document.createElement('option');
        optionElement.textContent = option.label;
        optionElement.value = option.value;
        dropdownMenu.appendChild(optionElement);
      });
  
      // Add hover transition
      dropdownMenu.addEventListener('mouseenter', function() {
        dropdownMenu.style.backgroundColor = '#f2f2f2';
      });
  
      dropdownMenu.addEventListener('mouseleave', function() {
        dropdownMenu.style.backgroundColor = 'transparent';
      });
  
      // Styling methods
      dropdownMenu.setStyle = function(styles) {
        Object.assign(dropdownMenu.style, styles);
      };
  
      return dropdownMenu;
    },
  
    // Checkbox widget
    Checkbox: function(label) {
      var checkboxContainer = document.createElement('label');
      checkboxContainer.className = 'vgl-ntl-checkbox-container';
  
      var checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'vgl-ntl-checkbox';
  
      var checkboxLabel = document.createElement('span');
      checkboxLabel.textContent = label;
  
      checkboxContainer.appendChild(checkbox);
      checkboxContainer.appendChild(checkboxLabel);
  
      // Add hover transition
      checkboxContainer.addEventListener('mouseenter', function() {
        checkboxContainer.style.backgroundColor = '#f2f2f2';
      });
  
      checkboxContainer.addEventListener('mouseleave', function() {
        checkboxContainer.style.backgroundColor = 'transparent';
      });
  
      // Styling methods
      checkboxContainer.setStyle = function(styles) {
        Object.assign(checkboxContainer.style, styles);
      };
  
      return checkboxContainer;
    },
  
// Radio button widget
RadioButton: function(name, options) {
    var radioButtonContainer = document.createElement('div');
    radioButtonContainer.className = 'vgl-ntl-radio-container';

    options.forEach(function(option) {
      var radioButton = document.createElement('input');
      radioButton.type = 'radio';
      radioButton.name = name;
      radioButton.value = option.value;
      radioButton.className = 'vgl-ntl-radio';

      var radioLabel = document.createElement('span');
      radioLabel.textContent = option.label;

      var radioItem = document.createElement('label');
      radioItem.className = 'vgl-ntl-radio-item';

      radioItem.appendChild(radioButton);
      radioItem.appendChild(radioLabel);
      radioButtonContainer.appendChild(radioItem);
    });

    // Add hover transition
    radioButtonContainer.addEventListener('mouseenter', function() {
      radioButtonContainer.style.backgroundColor = '#f2f2f2';
    });

    radioButtonContainer.addEventListener('mouseleave', function() {
      radioButtonContainer.style.backgroundColor = 'transparent';
    });

    // Styling methods
    radioButtonContainer.setStyle = function(styles) {
      Object.assign(radioButtonContainer.style, styles);
    };

    return radioButtonContainer;
  },

  // Slider widget
  Slider: function(minValue, maxValue) {
    var slider = document.createElement('input');
    slider.type = 'range';
    slider.min = minValue;
    slider.max = maxValue;
    slider.className = 'vgl-ntl-slider';

    // Add hover transition
    slider.addEventListener('mouseenter', function() {
      slider.style.backgroundColor = '#f2f2f2';
    });

    slider.addEventListener('mouseleave', function() {
      slider.style.backgroundColor = 'transparent';
    });

    // Styling methods
    slider.setStyle = function(styles) {
      Object.assign(slider.style, styles);
    };

    return slider;
  },

// Accordion widget
  Accordion: function(sections) {
    var accordion = document.createElement('div');
    accordion.className = 'vgl-ntl-accordion';

    sections.forEach(function(section) {
      var sectionElement = document.createElement('div');
      sectionElement.className = 'vgl-ntl-accordion-section';

      var header = document.createElement('div');
      header.textContent = section.title;
      header.className = 'vgl-ntl-accordion-header';

      var content = document.createElement('div');
      content.textContent = section.content;
      content.className = 'vgl-ntl-accordion-content';

      sectionElement.appendChild(header);
      sectionElement.appendChild(content);
      accordion.appendChild(sectionElement);
    });

    // Add hover transition
    accordion.addEventListener('mouseenter', function() {
      accordion.style.backgroundColor = '#f2f2f2';
    });

    accordion.addEventListener('mouseleave', function() {
      accordion.style.backgroundColor = 'transparent';
    });

    // Styling methods
    accordion.setStyle = function(styles) {
      Object.assign(accordion.style, styles);
    };

    return accordion;
  },

  // Tabbed panel widget
  TabbedPanel: function(tabs) {
    var tabbedPanel = document.createElement('div');
    tabbedPanel.className = 'vgl-ntl-tabbed-panel';

    var tabList = document.createElement('ul');
    tabList.className = 'vgl-ntl-tab-list';

    var tabContentContainer = document.createElement('div');
    tabContentContainer.className = 'vgl-ntl-tab-content-container';

    tabs.forEach(function(tab, index) {
      var tabListItem = document.createElement('li');
      tabListItem.textContent = tab.label;
      tabListItem.className = 'vgl-ntl-tab-list-item';
      tabListItem.dataset.index = index;

      tabListItem.addEventListener('click', function() {
        var selectedIndex = parseInt(this.dataset.index);
        var activeTabContent = tabContentContainer.querySelector('.vgl-ntl-tab-content.active');
        if (activeTabContent) {
          activeTabContent.classList.remove('active');
        }
        var selectedTabContent = tabContentContainer.querySelector('.vgl-ntl-tab-content[data-index="' + selectedIndex + '"]');
        if (selectedTabContent) {
          selectedTabContent.classList.add('active');
        }
      });

      tabList.appendChild(tabListItem);

      var tabContent = document.createElement('div');
      tabContent.textContent = tab.content;
      tabContent.className = 'vgl-ntl-tab-content';
      tabContent.dataset.index = index;
      if (index === 0) {
        tabContent.classList.add('active');
      }

      tabContentContainer.appendChild(tabContent);
    });

    tabbedPanel.appendChild(tabList);
    tabbedPanel.appendChild(tabContentContainer);

    // Add hover transition
    tabbedPanel.addEventListener('mouseenter', function() {
      tabbedPanel.style.backgroundColor = '#f2f2f2';
    });

    tabbedPanel.addEventListener('mouseleave', function() {
      tabbedPanel.style.backgroundColor = 'transparent';
    });

    // Styling methods
    tabbedPanel.setStyle = function(styles) {
      Object.assign(tabbedPanel.style, styles);
    };

    return tabbedPanel;
  },

 // Hierarchy widget
 Hierarchy: function(items) {
     var hierarchy = document.createElement('ul');
     hierarchy.className = 'vgl-ntl-hierarchy';
 
     function createItem(item) {
       var listItem = document.createElement('li');
       listItem.textContent = item.label;
       listItem.className = 'vgl-ntl-hierarchy-item';
 
       if (item.children && item.children.length > 0) {
         var sublist = document.createElement('ul');
         sublist.className = 'vgl-ntl-hierarchy-sublist';
         item.children.forEach(function(child) {
           sublist.appendChild(createItem(child));
         });
         listItem.appendChild(sublist);
       }
 
       return listItem;
     }
 
     items.forEach(function(item) {
       hierarchy.appendChild(createItem(item));
     });
 
     // Add hover transition
     hierarchy.addEventListener('mouseenter', function() {
       hierarchy.style.backgroundColor = '#f2f2f2';
     });
 
     hierarchy.addEventListener('mouseleave', function() {
       hierarchy.style.backgroundColor = 'transparent';
     });
 
     // Styling methods
     hierarchy.setStyle = function(styles) {
       Object.assign(hierarchy.style, styles);
     };
 
     return hierarchy;
   },
 
   // Inspector panel widget
   InspectorPanel: function(properties) {
     var inspectorPanel = document.createElement('div');
     inspectorPanel.className = 'vgl-ntl-inspector-panel';
 
     var propertyList = document.createElement('ul');
     propertyList.className = 'vgl-ntl-inspector-property-list';
 
     properties.forEach(function(property) {
       var listItem = document.createElement('li');
       listItem.textContent = property.label + ': ' + property.value;
       listItem.className = 'vgl-ntl-inspector-property';
       propertyList.appendChild(listItem);
     });
 
     inspectorPanel.appendChild(propertyList);
 
     // Add hover transition
     inspectorPanel.addEventListener('mouseenter', function() {
       inspectorPanel.style.backgroundColor = '#f2f2f2';
     });
 
     inspectorPanel.addEventListener('mouseleave', function() {
       inspectorPanel.style.backgroundColor = 'transparent';
     });
 
     // Styling methods
     inspectorPanel.setStyle = function(styles) {
       Object.assign(inspectorPanel.style, styles);
     };
 
     return inspectorPanel;
   }
 
   // Other complex widgets can be added similarly...
 };